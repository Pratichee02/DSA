#include <iostream>
using namespace std;


class arr_stack
{
public:
    int stack[100], n=100, top=-1;
    void push(int val)
    {
       if(top>=n-1)
       cout<<"Stack Full"<<endl;
       else {
          top++;
          stack[top]=val;
       }
    }


    void pop()
    {
       if(top<=-1)
       cout<<"Stack Empty"<<endl;
       else {
          cout<<"The popped element is "<< stack[top] <<endl;
          top--;
       }
    }


    void display()
    {
       if(top>=0) {
          cout<<"Stack = ";
          for(int i=top; i>=0; i--)
          cout<<stack[i]<<" ";
          cout<<endl;
       } else
       cout<<"Stack is empty";
    }
};


int main()
{
    arr_stack s1;

    int ch, val;
    cout<<"STACK USING ARRAY"<<endl;
    cout<<"1) Push in stack"<<endl;
    cout<<"2) Pop from stack"<<endl;
    cout<<"3) Display stack"<<endl;
    cout<<"4) Exit"<<endl;
    do {
      cout<<"Enter choice: "<<endl;
      cin>>ch;
      switch(ch)
      {
         case 1:
             {
                cout<<"Enter value to be pushed:"<<endl;
                cin>>val;
                s1.push(val);
                break;
             }
         case 2:
             {
                s1.pop();
                break;
             }
         case 3:
             {
                s1.display();
                break;
             }
         case 4:
             {
                break;
             }
         default:
             {
                cout<<"Invalid Choice"<<endl;
             }
      }
    }while(ch!=4);
    return 0;
}
