#include<iostream>
#include<string.h>
using namespace std;

class password
{
    char a[6];
    int i,j,k,l;
public:
    void passwrd();

};

void password::passwrd()
{
    int cnt=0;
    cout<<"Enter 6 alphanumeric values = ";
    for(i=0;i<6;i++)
    {
        cin>>a[i];
    }
    cout<<"Generated passwords are = "<<endl;
    for(i=0;i<6;i++)
    {
        for(j=0;j<6;j++)
        {
            for(k=0;k<6;k++)
            {
                for(l=0;l<6;l++)
                {
                    if((a[i]==a[j])||(a[i]==a[k])||(a[i]==a[l])||(a[j]==a[k])||(a[j]==a[l])||(a[k]==a[l]))
                    {
                        continue;
                    }
                    else
                    {
                        cout<<a[i]<<a[j]<<a[k]<<a[l]<<"\t ";
                        cnt++;
                    }

                }
            }
        }
    }
    cout<<"Count of generated passwords = "<<cnt;
}




int main()
{
    password p;
    p.passwrd();
    return 0;
}
